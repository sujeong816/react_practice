import React from 'react';
import './App.css';
import StudentContainer from './StudentContainer';

function App() {
  return (
    <StudentContainer/>
  );
}

export default App;
