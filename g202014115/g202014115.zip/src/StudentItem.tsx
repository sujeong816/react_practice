import type * as types from './types'

type Props = {
    student: types.Student
}

function StudentItem({student}: Props) {
    return(
        <tr>
            <td>{student.id}</td>
            <td>{student.stuNum}</td>
            <td>{student.stuName}</td>
        </tr>
    )
}