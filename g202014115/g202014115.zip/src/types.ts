export type Student = {
    id: number;
    stuNum: number;
    stuName: string;
}
export type AddStudentFunc = (text: string) => void;
export type ToogleStudentFunc = (id: number) => void;
export type DeleteStudentFunc = (id: number) => void;